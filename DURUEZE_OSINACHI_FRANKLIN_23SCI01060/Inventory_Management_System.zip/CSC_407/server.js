require('dotenv').config();
const express=require('express'),session=require('express-session'),helmet=require('helmet'),
rateLimit=require('express-rate-limit'),bcrypt=require('bcryptjs'),crypto=require('crypto'),Database=require('better-sqlite3');
if(!process.env.SESSION_SECRET){console.error('SESSION_SECRET missing');process.exit(1);}
const prod=process.env.NODE_ENV==='production';
const db=new Database(process.env.DB_FILE||'inventory.db');
db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'user');
CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY,item_name TEXT NOT NULL,sku TEXT NOT NULL,qty INTEGER NOT NULL,price REAL NOT NULL,by_user TEXT NOT NULL,created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS items(id INTEGER PRIMARY KEY,name TEXT NOT NULL,sku TEXT UNIQUE NOT NULL,category TEXT NOT NULL,qty INTEGER NOT NULL CHECK(qty>=0),price REAL NOT NULL CHECK(price>=0),updated TEXT DEFAULT CURRENT_TIMESTAMP);`);
for(const c of ['must_change INTEGER NOT NULL DEFAULT 0','reset_req INTEGER NOT NULL DEFAULT 0']){try{db.exec('ALTER TABLE users ADD COLUMN '+c)}catch{}}
const DEFAULT_PW=process.env.DEFAULT_PASSWORD||'Mascani1010';
if(!db.prepare("SELECT 1 FROM users WHERE role='admin'").get()&&process.env.ADMIN_PASSWORD)
  db.prepare('INSERT INTO users(name,email,hash,role) VALUES(?,?,?,?)').run('Admin',process.env.ADMIN_EMAIL||'admin@example.com',bcrypt.hashSync(process.env.ADMIN_PASSWORD,12),'admin');

const app=express(); if(prod)app.set('trust proxy',1);
app.use(helmet(prod?{}:{hsts:false,contentSecurityPolicy:{directives:{...helmet.contentSecurityPolicy.getDefaultDirectives(),'upgrade-insecure-requests':null}}}));
app.use(express.urlencoded({extended:false,limit:'10kb'}));
app.use(session({name:'sid',secret:process.env.SESSION_SECRET,resave:false,saveUninitialized:false,
  cookie:{httpOnly:true,sameSite:'lax',secure:prod,maxAge:30*60*1000}}));
// CSRF: per-session token required on every POST
app.use((req,res,next)=>{
  req.session.csrf??=crypto.randomBytes(24).toString('hex');
  if(req.method==='POST'&&req.body._csrf!==req.session.csrf)return res.status(403).send(page(req,'Forbidden','<p class="err">Invalid form token.</p>'));
  next();});

const CLIENT_JS=`
document.querySelectorAll('input[type=password]').forEach(i=>{const w=document.createElement('div');w.className='pw';i.before(w);
const b=document.createElement('button');b.type='button';b.className='eye';b.textContent='Show';
b.title='Press and hold to view';b.addEventListener('pointerdown',e=>{e.preventDefault();i.type='text';});['pointerup','pointerleave','pointercancel'].forEach(t=>b.addEventListener(t,()=>{i.type='password';}));b.addEventListener('contextmenu',e=>e.preventDefault());w.append(i,b);});
document.addEventListener('click',e=>{const t=e.target.closest('[data-confirm]');if(t&&!confirm(t.dataset.confirm))e.preventDefault();});
`;
app.get('/app.js',(req,res)=>res.type('application/javascript').send(CLIENT_JS));
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const csrf=req=>`<input type="hidden" name="_csrf" value="${req.session.csrf}">`;
const css=`*{box-sizing:border-box}body{font:16px system-ui;margin:0;background:#f4f6f8;color:#1b1f24}
nav{background:linear-gradient(90deg,#1f3a5f,#2c5282);display:flex;flex-wrap:wrap;align-items:center;gap:6px;padding:10px 16px;box-shadow:0 2px 6px #0003}nav .brand{color:#fff;font-weight:700;font-size:18px;margin-right:12px}nav a{color:#dbe7f5;text-decoration:none;padding:8px 14px;border-radius:999px;font-weight:500}nav a:hover{background:#ffffff26;color:#fff}nav a.on{background:#fff;color:#1f3a5f}
main{max-width:960px;margin:auto;padding:16px}.card{background:#fff;border-radius:8px;padding:16px;margin:12px 0;box-shadow:0 1px 3px #0002}
.pw{position:relative}.pw input{padding-right:72px}.pw .eye{position:absolute;right:6px;top:50%;transform:translateY(-50%);background:none;color:#1f3a5f;border:0;padding:6px 8px;margin:0;width:auto;font-size:14px;font-weight:600;cursor:pointer}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}.big{font-size:28px;font-weight:700}
input,select,button{padding:10px;font:inherit;border:1px solid #bbb;border-radius:6px;width:100%;margin:4px 0}
button,.btn{background:#1f3a5f;color:#fff;border:0;cursor:pointer;width:auto;padding:10px 16px;text-decoration:none;border-radius:6px;display:inline-block}
.danger{background:#b3261e}.err{color:#b3261e}.low{background:#fff3cd}.tbl{overflow-x:auto}table{border-collapse:collapse;width:100%}
td,th{padding:8px;border-bottom:1px solid #ddd;text-align:left;white-space:nowrap}form.inline{display:inline}@media(min-width:700px){.row{display:flex;gap:8px}}`;
const naira=n=>'₦'+Number(n).toLocaleString('en-NG',{minimumFractionDigits:2,maximumFractionDigits:2});
function page(req,title,body){const u=req.session?.user;
const L=(p,t)=>`<a href="${p}"${req.path===p||(p!=='/'&&req.path.startsWith(p))?' class="on"':''}>${t}</a>`;
return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)} · Mascani Multisystems Limited</title><style>${css}</style><script src="/app.js" defer></script></head><body>
<nav><span class="brand">📦 Mascani Multisystems Limited</span>${u?`${L('/','Dashboard')}${L('/items','Inventory')}${L('/sales','Sales')}${L('/profile','Profile')}${u.role==='admin'?L('/admin/users','Users')+L('/security','Security'):''}
<form class="inline" method="post" action="/logout" style="margin-left:auto">${csrf(req)}<button class="danger" style="border-radius:4px;margin:0">Logout (${esc(u.name)})</button></form>`:`${L('/login','Login')}`}</nav>
<main>${body}</main></body></html>`;}
const need=role=>(req,res,next)=>{const u=req.session.user;
  if(!u)return res.redirect('/login');
  if(u.mc&&req.path!=='/profile')return res.redirect('/profile');
  if(role&&u.role!==role){log('ACCESS_DENIED',req);return res.status(403).send(page(req,'Denied','<div class="card err">403 – Access denied</div>'));}
  next();};
const log=(ev,req)=>console.log(JSON.stringify({t:new Date().toISOString(),ev,ip:req.ip,user:req.session?.user?.id??null,path:req.path}));
const strong=p=>typeof p==='string'&&p.length>=10&&/[a-z]/.test(p)&&/[A-Z]/.test(p)&&/\d/.test(p);
const emailOk=e=>typeof e==='string'&&e.length<=254&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);
const authLimit=rateLimit({windowMs:15*60*1000,limit:10,standardHeaders:true,legacyHeaders:false});

// ---- auth ----
const authForm=(req,reg,err='')=>page(req,reg?'Register':'Login',`<div class="card"><h2>${reg?'Register':'Login'}</h2><p class="err">${esc(err)}</p>
<form method="post">${csrf(req)}${reg?'<input name="name" placeholder="Full name" required maxlength="60">':''}
<input name="email" type="email" placeholder="Email" required><input name="password" type="password" placeholder="Password${reg?' (10+ chars, upper, lower, digit)':''}" required>
<button>${reg?'Create account':'Sign in'}</button></form><p><a href="/forgot">Forgot password?</a></p></div>`);
app.get('/login',(req,res)=>res.send(authForm(req,false)));
app.post('/login',authLimit,(req,res)=>{const{email,password}=req.body;
  const u=typeof email==='string'?db.prepare('SELECT * FROM users WHERE email=?').get(email.toLowerCase()):null;
  const ok=bcrypt.compareSync(String(password??''),u?u.hash:'$2a$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvalidi');
  if(!u||!ok){log('LOGIN_FAIL',req);return res.status(401).send(authForm(req,false,'Invalid email or password.'));}
  req.session.regenerate(()=>{req.session.csrf=crypto.randomBytes(24).toString('hex');
    req.session.user={id:u.id,name:u.name,role:u.role,mc:!!u.must_change};log('LOGIN_OK',req);res.redirect('/');});});
const forgotPage=(req,msg='')=>page(req,'Forgot password',`<div class="card"><h2>Forgot password</h2><p>Enter your account email. An administrator will be notified and will reset your password to the default one.</p><p>${esc(msg)}</p><form method="post">${csrf(req)}<input name="email" type="email" placeholder="Email" required><button>Request reset</button></form><p><a href="/login">Back to login</a></p></div>`);
app.get('/forgot',(req,res)=>res.send(forgotPage(req)));
app.post('/forgot',authLimit,(req,res)=>{if(emailOk(req.body.email))db.prepare('UPDATE users SET reset_req=1 WHERE email=?').run(req.body.email.toLowerCase());
  res.send(forgotPage(req,'If that email has an account, the administrator has been notified.'));});
app.post('/logout',(req,res)=>req.session.destroy(()=>{res.clearCookie('sid');res.redirect('/login');}));

// ---- dashboard ----
app.get('/',need(),(req,res)=>{
  const s=db.prepare('SELECT COUNT(*) n,COALESCE(SUM(qty),0) q,COALESCE(SUM(qty*price),0) v,COALESCE(SUM(qty<5),0) low FROM items').get();
  res.send(page(req,'Dashboard',`<h2>Welcome, ${esc(req.session.user.name)}</h2><div class="grid">
<div class="card">Products<div class="big">${s.n}</div></div><div class="card">Units<div class="big">${s.q}</div></div>
<div class="card">Stock value<div class="big">₦${s.v.toLocaleString("en-NG",{minimumFractionDigits:2,maximumFractionDigits:2})}</div></div><div class="card">Low stock (&lt;5)<div class="big">${s.low}</div></div></div>
<a class="btn" href="/items/new">+ Add item</a>`));});

// ---- items ----
const cats=['General','Electronics','Office','Tools','Other'];
function parseItem(b){const e=[];const name=String(b.name??'').trim(),sku=String(b.sku??'').trim(),category=String(b.category??'');
  const qty=Number(b.qty),price=Number(b.price);
  if(!name||name.length>80)e.push('Name 1-80 chars.');if(!/^[A-Za-z0-9-]{2,20}$/.test(sku))e.push('SKU: 2-20 letters/digits/dashes.');
  if(!cats.includes(category))e.push('Invalid category.');if(!Number.isInteger(qty)||qty<0||qty>1e6)e.push('Quantity must be a whole number ≥ 0.');
  if(!Number.isFinite(price)||price<0||price>1e7)e.push('Price must be ≥ 0.');
  return{e,v:{name,sku,category,qty,price}};}
const itemForm=(req,it={},err='',action='/items')=>page(req,'Item',`<div class="card"><h2>${it.id?'Edit':'New'} item</h2><p class="err">${esc(err)}</p>
<form method="post" action="${action}">${csrf(req)}<input name="name" placeholder="Name" value="${esc(it.name)}" required>
<input name="sku" placeholder="SKU" value="${esc(it.sku)}" required><select name="category">${cats.map(c=>`<option${c===it.category?' selected':''}>${c}</option>`).join('')}</select>
<div class="row"><input name="qty" type="number" min="0" step="1" placeholder="Qty" value="${esc(it.qty)}" required><input name="price" type="number" min="0" step="0.01" placeholder="Price (₦)" value="${esc(it.price)}" required></div>
<button>Save</button></form></div>`);
app.get('/items',need(),(req,res)=>{const q=String(req.query.q??'').slice(0,50),c=String(req.query.c??'');
  const rows=db.prepare("SELECT * FROM items WHERE (name LIKE ? OR sku LIKE ?) AND (?='' OR category=?) ORDER BY name").all(`%${q}%`,`%${q}%`,c,c);
  const admin=req.session.user.role==='admin';
  res.send(page(req,'Inventory',`<h2>Inventory</h2><form class="card row" method="get"><input name="q" placeholder="Search name or SKU" value="${esc(q)}">
<select name="c"><option value="">All categories</option>${cats.map(x=>`<option${x===c?' selected':''}>${x}</option>`).join('')}</select><button>Filter</button></form>
<a class="btn" href="/items/new">+ Add item</a><div class="card tbl"><table><tr><th>Name</th><th>SKU</th><th>Category</th><th>Qty</th><th>Price</th><th></th></tr>
${rows.map(r=>`<tr class="${r.qty<5?'low':''}"><td>${esc(r.name)}</td><td>${esc(r.sku)}</td><td>${esc(r.category)}</td><td>${r.qty}</td><td>₦${r.price.toLocaleString("en-NG",{minimumFractionDigits:2,maximumFractionDigits:2})}</td>
<td>${r.qty>0?`<form class="inline" method="post" action="/items/${r.id}/sell">${csrf(req)}<input name="qty" type="number" min="1" max="${r.qty}" value="1" style="width:70px;padding:6px"><button style="padding:6px 10px;background:#2e7d32">Sell</button></form> `:''}<a href="/items/${r.id}/edit">Edit</a>${admin?` <form class="inline" method="post" action="/items/${r.id}/delete">${csrf(req)}<button class="danger" data-confirm="Delete?">Delete</button></form>`:''}</td></tr>`).join('')||'<tr><td colspan="6">No items found.</td></tr>'}</table></div>`));});
app.get('/items/new',need(),(req,res)=>res.send(itemForm(req)));
app.post('/items',need(),(req,res)=>{const{e,v}=parseItem(req.body);if(e.length)return res.status(400).send(itemForm(req,v,e.join(' ')));
  try{db.prepare('INSERT INTO items(name,sku,category,qty,price) VALUES(@name,@sku,@category,@qty,@price)').run(v);res.redirect('/items');}
  catch{res.status(400).send(itemForm(req,v,'SKU already exists.'));}});
app.get('/items/:id/edit',need(),(req,res)=>{const it=db.prepare('SELECT * FROM items WHERE id=?').get(req.params.id);
  it?res.send(itemForm(req,it,'',`/items/${it.id}/edit`)):res.status(404).send(page(req,'404','<div class="card">Not found</div>'));});
app.post('/items/:id/edit',need(),(req,res)=>{const{e,v}=parseItem(req.body);const id=Number(req.params.id);
  if(e.length)return res.status(400).send(itemForm(req,{...v,id},e.join(' '),`/items/${id}/edit`));
  try{db.prepare('UPDATE items SET name=@name,sku=@sku,category=@category,qty=@qty,price=@price,updated=CURRENT_TIMESTAMP WHERE id=@id').run({...v,id});res.redirect('/items');}
  catch{res.status(400).send(itemForm(req,{...v,id},'SKU already exists.',`/items/${id}/edit`));}});
const sell=(req,res,id,n)=>{
  const it=db.prepare('SELECT * FROM items WHERE id=?').get(id);
  if(!it||!Number.isInteger(n)||n<1||n>it.qty)return res.status(400).send(page(req,'Sale failed','<div class="card err">Invalid quantity or not enough stock.</div><a class="btn" href="/items">Back</a>'));
  db.transaction(()=>{db.prepare('UPDATE items SET qty=qty-?,updated=CURRENT_TIMESTAMP WHERE id=?').run(n,id);
    db.prepare('INSERT INTO sales(item_name,sku,qty,price,by_user) VALUES(?,?,?,?,?)').run(it.name,it.sku,n,it.price,req.session.user.name);})();
  log('SALE',req);res.redirect('/sales');};
app.post('/items/:id/sell',need(),(req,res)=>sell(req,res,Number(req.params.id),Number(req.body.qty)));
app.post('/sales',need(),(req,res)=>sell(req,res,Number(req.body.item_id),Number(req.body.qty)));
app.get('/sales',need(),(req,res)=>{const rows=db.prepare('SELECT * FROM sales ORDER BY id DESC LIMIT 200').all();
  const tot=db.prepare('SELECT COALESCE(SUM(qty*price),0) t FROM sales').get().t;
  const avail=db.prepare('SELECT id,name,sku,qty FROM items WHERE qty>0 ORDER BY name').all();
  res.send(page(req,'Sales',`<h2>Sales</h2><div class="card"><h3>Record a sale</h3><form method="post" action="/sales">${csrf(req)}
<select name="item_id" required><option value="">Select item…</option>${avail.map(i=>`<option value="${i.id}">${esc(i.name)} (${esc(i.sku)}) – ${i.qty} in stock</option>`).join('')}</select>
<input name="qty" type="number" min="1" step="1" value="1" required><button>Record sale</button></form></div><div class="card">Total sales<div class="big">${naira(tot)}</div></div><div class="card tbl"><table><tr><th>Date</th><th>Item</th><th>SKU</th><th>Qty</th><th>Amount</th><th>By</th></tr>
${rows.map(r=>`<tr><td>${esc(r.created)}</td><td>${esc(r.item_name)}</td><td>${esc(r.sku)}</td><td>${r.qty}</td><td>${naira(r.qty*r.price)}</td><td>${esc(r.by_user)}</td></tr>`).join('')||'<tr><td colspan="6">No sales yet.</td></tr>'}</table></div>`));});
app.post('/items/:id/delete',need('admin'),(req,res)=>{db.prepare('DELETE FROM items WHERE id=?').run(req.params.id);log('ITEM_DELETE',req);res.redirect('/items');});

// ---- profile / admin / security ----
const profile=(req,msg='')=>{const u=db.prepare('SELECT name,email,role FROM users WHERE id=?').get(req.session.user.id);
  return page(req,'Profile',`<div class="card"><h2>Profile</h2><p>${esc(u.name)} · ${esc(u.email)} · role: <b>${esc(u.role)}</b></p><p>${esc(msg)}</p>${req.session.user.mc?'<p class="err">You are using a default password. Set a new one to continue.</p>':''}
<h3>Change password</h3><form method="post">${csrf(req)}<input name="old" type="password" placeholder="Current password" required><input name="pw" type="password" placeholder="New password" required><button>Update</button></form></div>`);};
app.get('/profile',need(),(req,res)=>res.send(profile(req)));
app.post('/profile',need(),(req,res)=>{const u=db.prepare('SELECT hash FROM users WHERE id=?').get(req.session.user.id);
  if(!bcrypt.compareSync(String(req.body.old??''),u.hash))return res.send(profile(req,'Current password is wrong.'));
  if(!strong(req.body.pw))return res.send(profile(req,'New password too weak.'));
  if(req.body.pw===req.body.old)return res.send(profile(req,'New password must be different.'));
  db.prepare('UPDATE users SET hash=?,must_change=0 WHERE id=?').run(bcrypt.hashSync(req.body.pw,12),req.session.user.id);req.session.user.mc=false;res.send(profile(req,'Password updated.'));});
app.get('/admin/users',need('admin'),(req,res)=>{const us=db.prepare('SELECT id,name,email,role,reset_req FROM users').all();
  res.send(page(req,'Users',`<h2>Users</h2><div class="card"><h3>Create account</h3><form method="post" action="/admin/users">${csrf(req)}
<input name="name" placeholder="Full name" required maxlength="60"><input name="email" type="email" placeholder="Email" required>
<p>New accounts get the default password <b>${esc(DEFAULT_PW)}</b> and must change it at first login.</p>
<select name="role"><option value="user">User</option><option value="admin">Admin</option></select><button>Create user</button></form></div><div class="card tbl"><table><tr><th>Name</th><th>Email</th><th>Role</th><th></th></tr>${us.map(u=>`<tr><td>${esc(u.name)}${u.reset_req?' <b class="err">⚠ reset requested</b>':''}</td><td>${esc(u.email)}</td><td>${esc(u.role)}</td>
<td>${u.id!==req.session.user.id?`<form class="inline" method="post" action="/admin/users/${u.id}/role">${csrf(req)}<input type="hidden" name="role" value="${u.role==='admin'?'user':'admin'}"><button>Make ${u.role==='admin'?'user':'admin'}</button></form> <form class="inline" method="post" action="/admin/users/${u.id}/delete">${csrf(req)}<button class="danger" data-confirm="Delete this user?">Delete</button></form> <form class="inline" method="post" action="/admin/users/${u.id}/reset">${csrf(req)}<button style="background:#b26a00" data-confirm="Reset password to the default?">Reset password</button></form>`:''}</td></tr>`).join('')}</table></div>`));});
app.post('/admin/users',need('admin'),(req,res)=>{const{name,email,role}=req.body;
  const fail=m=>res.status(400).send(page(req,'Error',`<div class="card err">${m}</div><a class="btn" href="/admin/users">Back</a>`));
  if(typeof name!=='string'||!name.trim()||name.length>60)return fail('Valid name required.');
  if(!emailOk(email))return fail('Valid email required.');
  try{db.prepare('INSERT INTO users(name,email,hash,role,must_change) VALUES(?,?,?,?,1)').run(name.trim(),email.toLowerCase(),bcrypt.hashSync(DEFAULT_PW,12),role==='admin'?'admin':'user');}
  catch{return fail('That email already has an account.');}
  log('USER_CREATE',req);res.redirect('/admin/users');});
app.post('/admin/users/:id/reset',need('admin'),(req,res)=>{if(Number(req.params.id)!==req.session.user.id){db.prepare('UPDATE users SET hash=?,must_change=1,reset_req=0 WHERE id=?').run(bcrypt.hashSync(DEFAULT_PW,12),req.params.id);log('PW_RESET',req);}res.redirect('/admin/users');});
app.post('/admin/users/:id/role',need('admin'),(req,res)=>{if(['admin','user'].includes(req.body.role)&&Number(req.params.id)!==req.session.user.id)
  db.prepare('UPDATE users SET role=? WHERE id=?').run(req.body.role,req.params.id);res.redirect('/admin/users');});
app.post('/admin/users/:id/delete',need('admin'),(req,res)=>{if(Number(req.params.id)!==req.session.user.id){db.prepare('DELETE FROM users WHERE id=?').run(req.params.id);log('USER_DELETE',req);}res.redirect('/admin/users');});
app.get('/security',need('admin'),(req,res)=>res.send(page(req,'Security',`<div class="card"><h2>Security measures</h2><ul>
<li><b>Passwords:</b> bcrypt (cost 12), never stored in plain text; strength rules enforced.</li>
<li><b>SQL injection:</b> every query is parameterised (prepared statements).</li>
<li><b>XSS:</b> all output HTML-escaped; Helmet sets CSP and other headers.</li>
<li><b>CSRF:</b> per-session token on every POST; SameSite=Lax cookies.</li>
<li><b>Sessions:</b> HttpOnly, Secure (production), 30-min expiry, ID regenerated at login, destroyed at logout.</li>
<li><b>Account creation:</b> no public sign-up; only admins can create accounts. Default passwords must be changed at first login; admins handle password resets.</li>
<li><b>Access control:</b> Admin/User roles checked server-side on every protected route.</li>
<li><b>Brute force:</b> login rate-limited; generic error messages.</li>
<li><b>Secrets:</b> kept in environment variables, not in code.</li>
<li><b>Logging:</b> failed logins and denied access are logged.</li></ul></div>`)));
app.use((req,res)=>res.status(404).send(page(req,'404','<div class="card">Page not found</div>')));
app.use((err,req,res,next)=>{console.error(err);res.status(500).send(page(req,'Error','<div class="card err">Something went wrong.</div>'));});
app.listen(process.env.PORT||3000,()=>console.log('Running on port '+(process.env.PORT||3000)));
