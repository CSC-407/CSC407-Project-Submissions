# Inventory Management System (Node.js + Express + SQLite)

## Run locally
```
npm install
cp .env.example .env     # set SESSION_SECRET and ADMIN_PASSWORD
npm start                # http://localhost:3000
```
Log in with ADMIN_EMAIL / ADMIN_PASSWORD (created on first start). New registrations get the `user` role.

## Pages
Dashboard · Register · Login · Profile (change password) · Inventory (search + category filter, add/edit, admin-only delete) · Admin Users (role management) · Security page.

## Security implemented
| Area | Implementation |
|---|---|
| Auth | Login/logout, generic error messages |
| Password hashing | bcrypt, cost 12 |
| Roles | admin / user, checked server-side (`need('admin')`) |
| Input validation | Server-side checks on every form; DB CHECK constraints |
| SQL injection | Prepared statements only |
| XSS | `esc()` on all output + Helmet CSP |
| CSRF | Per-session token on all POSTs |
| Sessions | HttpOnly, SameSite, Secure in production, 30 min, regenerated on login |
| Brute force | express-rate-limit (10 attempts / 15 min) |
| Secrets | `.env`, excluded by `.gitignore` |

## Test plan (fill in Actual Result / Status as you test)
| # | Type | Test | Expected | Actual | Status |
|---|---|---|---|---|---|
| 1 | Login | Valid credentials | Dashboard shown | | |
| 2 | Login | Wrong password | "Invalid email or password" | | |
| 3 | Registration | Empty field | Validation message | | |
| 4 | Registration | Weak password | "Password too weak" | | |
| 5 | Registration | Duplicate email | Generic failure message | | |
| 6 | Access control | User opens /admin/users | 403 Access denied | | |
| 7 | Access control | Logged-out user opens /items | Redirect to /login | | |
| 8 | Access control | User POSTs item delete | 403 | | |
| 9 | Security | `' OR 1=1 --` in login/search | No bypass, no error | | |
| 10 | Security | `<script>alert(1)</script>` as item name | Shown as text, not run | | |
| 11 | Security | POST without CSRF token | 403 | | |
| 12 | Security | 11 failed logins quickly | Rate-limited (429) | | |
| 13 | Forms | Negative quantity / bad SKU | Validation error | | |
| 14 | Forms | Duplicate SKU | "SKU already exists" | | |
| 15 | Functional | Add, edit, search, filter item | Table updates correctly | | |
| 16 | Database | Check `users.hash` in SQLite | Bcrypt hash, no plain text | | |
| 17 | Responsive | Phone width (~375px) | No sideways page scroll, menu wraps | | |
| 18 | Usability | New user adds an item unaided | Done in under 1 min | | |
| 19 | Errors | Visit /nope and /items/999/edit | 404 page | | |
| 20 | Session | Logout, then press Back | Protected page not accessible | | |

## Deployment
1. **Environments:** development uses `.env` locally; production sets `NODE_ENV=production` and real secrets in the host's environment settings.
2. **Hosting:** e.g. Render, Railway, Fly.io or a VPS. Build: `npm install`, start: `npm start`.
3. **HTTPS:** platform-managed certificate, or on a VPS nginx reverse proxy + Let's Encrypt (`certbot --nginx`). The app trusts the proxy in production so Secure cookies work.
4. **Database:** SQLite file on a persistent disk (set `DB_FILE`). For many users, move to PostgreSQL.
5. **Backups:** scheduled copy of the DB file (`sqlite3 inventory.db ".backup backup.db"` via cron), stored off-server.
6. **Monitoring:** app prints JSON logs (login failures, denied access, deletes); view with the host's log viewer or `pm2 logs`. Use `pm2` or systemd to restart on crash.
7. **Process:** test locally → push to Git → host auto-deploys → smoke-test login and one inventory action.

## Project review
- **What it does:** lets staff track stock, with role-based control over who can delete or manage users.
- **Features:** see Pages above.
- **Security:** see table above.
- **Testing results:** complete the test table and summarise pass/fail counts here.
- **Performance:** record observations from your own runs (e.g. page load time with 1,000 items).
- **Problems encountered:** write your own (e.g. CSRF handling, session expiry, rate-limit tuning).
- **Limitations:** in-memory session store (logs out on restart, single server only); SQLite limits concurrent writes; no email verification or password reset; no 2FA; no stock-movement history; no pagination.
- **Future improvements:** PostgreSQL + persistent session store, password reset by email, 2FA, audit log, stock history and low-stock alerts, CSV import/export, pagination, automated tests.
